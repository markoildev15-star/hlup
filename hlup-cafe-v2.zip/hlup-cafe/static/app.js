const cartKey = 'hlup-cart-v2';
let cart = [];
try { cart = JSON.parse(localStorage.getItem(cartKey) || '[]'); } catch (_) { cart = []; }

const drawer = document.getElementById('cartDrawer');
const countEl = document.getElementById('cartCount');
const itemsEl = document.getElementById('cartItems');
const totalEl = document.getElementById('cartTotal');
const toast = document.getElementById('toast');

function escapeHtml(value){
  return String(value).replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));
}
function formatNumber(value){
  const n = Number(value || 0);
  return Number.isInteger(n) ? String(n) : n.toFixed(2).replace(/0+$/,'').replace(/\.$/,'');
}
function money(price, currency){ return `${formatNumber(price)} ${currency || '₽'}`; }
function saveCart(){ localStorage.setItem(cartKey, JSON.stringify(cart)); renderCart(); }
function showToast(message){
  if(!toast) return;
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(()=>toast.classList.remove('show'), 1700);
}
function addToCart(id,name,price,currency){
  const found = cart.find(x => x.id === id);
  if(found) found.qty += 1;
  else cart.push({id,name,price:Number(price),currency:currency || '₽',qty:1});
  saveCart();
  showToast('Ням! Уже в корзинке ✦');
}
function changeQty(id, delta){
  const found = cart.find(x => x.id === id);
  if(!found) return;
  found.qty += delta;
  if(found.qty <= 0) cart = cart.filter(x => x.id !== id);
  saveCart();
}
function groupedTotals(){
  const totals = {};
  cart.forEach(x => { totals[x.currency] = (totals[x.currency] || 0) + Number(x.price) * x.qty; });
  return Object.entries(totals).map(([currency,total]) => money(total,currency)).join(' + ');
}
function renderCart(){
  if(!countEl) return;
  countEl.textContent = cart.reduce((s,x)=>s+x.qty,0);
  if(itemsEl){
    itemsEl.innerHTML = cart.length ? cart.map(x => `
      <div class="cart-item">
        <div><strong>${escapeHtml(x.name)}</strong><br><small>${money(x.price,x.currency)} за штуку</small></div>
        <div class="cart-item-controls">
          <button type="button" onclick="changeQty(${x.id},-1)">−</button>
          <b>${x.qty}</b>
          <button type="button" onclick="changeQty(${x.id},1)">+</button>
        </div>
      </div>`).join('') : '<div class="cart-empty">Тут пока пусто.<br>Нямни что-нибудь 👀</div>';
  }
  if(totalEl) totalEl.textContent = cart.length ? groupedTotals() : '0 ₽';
}
function openCart(){ if(drawer){ drawer.classList.add('open'); drawer.setAttribute('aria-hidden','false'); document.body.style.overflow='hidden'; } }
function closeCart(){ if(drawer){ drawer.classList.remove('open'); drawer.setAttribute('aria-hidden','true'); document.body.style.overflow=''; } }

document.getElementById('openCart')?.addEventListener('click', openCart);
document.getElementById('closeCart')?.addEventListener('click', closeCart);
document.getElementById('closeCartX')?.addEventListener('click', closeCart);

document.getElementById('fakeOrder')?.addEventListener('click', async () => {
  if(!cart.length){ showToast('Сначала добавь хоть один ням 😭'); return; }
  const button = document.getElementById('fakeOrder');
  const original = button.textContent;
  button.disabled = true;
  button.textContent = 'Записываем хлюп…';
  try{
    const response = await fetch('/api/order', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({
        customer_name:document.getElementById('customerName')?.value || '',
        note:document.getElementById('orderNote')?.value || '',
        items:cart.map(({id,qty}) => ({id,qty}))
      })
    });
    const data = await response.json();
    if(!response.ok || !data.ok) throw new Error(data.error || 'Не получилось записать заказ.');
    cart = [];
    saveCart();
    document.getElementById('customerName').value = '';
    document.getElementById('orderNote').value = '';
    showToast(`${data.message} ✦`);
    setTimeout(closeCart, 900);
  }catch(err){
    showToast(err.message || 'Ой, заказ захлюпался :(');
  }finally{
    button.disabled = false;
    button.textContent = original;
  }
});

document.addEventListener('keydown', e => { if(e.key === 'Escape') closeCart(); });
renderCart();
