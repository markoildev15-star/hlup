import json
import os
import sqlite3
import uuid
from datetime import datetime
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.utils import secure_filename

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, 'cafe.db')
UPLOAD_DIR = os.path.join(BASE_DIR, 'static', 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp', 'gif'}

os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'change-me-in-production')
app.config['MAX_CONTENT_LENGTH'] = 6 * 1024 * 1024
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'hlup123')


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def column_names(conn, table):
    return {row['name'] for row in conn.execute(f'PRAGMA table_info({table})').fetchall()}


def init_db():
    conn = db()
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS dishes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT NOT NULL DEFAULT '',
            price REAL NOT NULL DEFAULT 0,
            currency TEXT NOT NULL DEFAULT '₽',
            emoji TEXT NOT NULL DEFAULT '🍽️',
            image_path TEXT NOT NULL DEFAULT '',
            available INTEGER NOT NULL DEFAULT 1,
            featured INTEGER NOT NULL DEFAULT 0,
            sort_order INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_name TEXT NOT NULL DEFAULT '',
            note TEXT NOT NULL DEFAULT '',
            items_json TEXT NOT NULL,
            total_text TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL,
            done INTEGER NOT NULL DEFAULT 0
        );
    ''')

    # Мягкая миграция старой базы из первой версии.
    cols = column_names(conn, 'dishes')
    if 'currency' not in cols:
        conn.execute("ALTER TABLE dishes ADD COLUMN currency TEXT NOT NULL DEFAULT '₽'")
    if 'image_path' not in cols:
        conn.execute("ALTER TABLE dishes ADD COLUMN image_path TEXT NOT NULL DEFAULT ''")

    count = conn.execute('SELECT COUNT(*) AS c FROM dishes').fetchone()['c']
    if count == 0:
        conn.executemany(
            '''INSERT INTO dishes
               (name, description, price, currency, emoji, image_path, available, featured, sort_order)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
            [
                ('Хлюп-бургер', 'Булочка, котлетка, сыр и тот самый хлюп-соус.', 4.90, '$', '🍔', '', 1, 1, 1),
                ('Ням-картошка', 'Хрустящая картошка с доброй щепоткой специй.', 2.50, '$', '🍟', '', 1, 0, 2),
                ('Клубничный хлюп', 'Сладкий розовый напиток с клубничным настроением.', 3.20, '$', '🥤', '', 1, 0, 3),
                ('Печенька «ой»', 'Печенька, которую будто нарисовали на полях тетради.', 1.50, '$', '🍪', '', 1, 0, 4),
            ]
        )
    conn.commit()
    conn.close()


def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get('admin'):
            return redirect(url_for('admin_login'))
        return fn(*args, **kwargs)
    return wrapper


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def save_image(file_storage):
    if not file_storage or not file_storage.filename:
        return ''
    if not allowed_file(file_storage.filename):
        raise ValueError('Можно загрузить PNG, JPG, WEBP или GIF.')
    original = secure_filename(file_storage.filename)
    ext = original.rsplit('.', 1)[1].lower()
    filename = f'{uuid.uuid4().hex}.{ext}'
    file_storage.save(os.path.join(UPLOAD_DIR, filename))
    return f'uploads/{filename}'


def remove_image(path):
    if not path or not path.startswith('uploads/'):
        return
    full = os.path.abspath(os.path.join(BASE_DIR, 'static', path))
    if full.startswith(os.path.abspath(UPLOAD_DIR) + os.sep) and os.path.isfile(full):
        try:
            os.remove(full)
        except OSError:
            pass


def parse_price(raw):
    try:
        return max(0, round(float(str(raw).replace(',', '.')), 2))
    except (TypeError, ValueError):
        return 0.0


def format_price(value):
    value = float(value)
    if value.is_integer():
        return str(int(value))
    return f'{value:.2f}'.rstrip('0').rstrip('.')


@app.context_processor
def helpers():
    return {'format_price': format_price}


@app.route('/')
def index():
    conn = db()
    dishes = conn.execute('SELECT * FROM dishes ORDER BY sort_order, id').fetchall()
    conn.close()
    return render_template('index.html', dishes=dishes)


@app.route('/api/dishes')
def api_dishes():
    conn = db()
    dishes = [dict(row) for row in conn.execute('SELECT * FROM dishes ORDER BY sort_order, id').fetchall()]
    conn.close()
    return jsonify(dishes)


@app.post('/api/order')
def create_order():
    payload = request.get_json(silent=True) or {}
    raw_items = payload.get('items') or []
    customer_name = str(payload.get('customer_name') or '').strip()[:60]
    note = str(payload.get('note') or '').strip()[:300]

    if not raw_items:
        return jsonify({'ok': False, 'error': 'Корзинка пустая.'}), 400

    normalized = {}
    for raw in raw_items[:50]:
        try:
            dish_id = int(raw.get('id'))
            qty = max(1, min(int(raw.get('qty', 1)), 20))
        except (TypeError, ValueError, AttributeError):
            continue
        normalized[dish_id] = min(normalized.get(dish_id, 0) + qty, 20)

    if not normalized:
        return jsonify({'ok': False, 'error': 'Не получилось прочитать заказ.'}), 400

    conn = db()
    placeholders = ','.join('?' for _ in normalized)
    rows = conn.execute(
        f'SELECT * FROM dishes WHERE id IN ({placeholders})',
        tuple(normalized.keys())
    ).fetchall()

    items = []
    totals = {}
    for row in rows:
        if not row['available']:
            continue
        qty = normalized[row['id']]
        subtotal = float(row['price']) * qty
        currency = row['currency'] or '₽'
        totals[currency] = totals.get(currency, 0) + subtotal
        items.append({
            'id': row['id'],
            'name': row['name'],
            'qty': qty,
            'price': float(row['price']),
            'currency': currency,
        })

    if not items:
        conn.close()
        return jsonify({'ok': False, 'error': 'Эти блюда сейчас недоступны.'}), 400

    total_text = ' + '.join(
        f'{format_price(total)} {currency}' for currency, total in totals.items()
    )
    created_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    cursor = conn.execute(
        '''INSERT INTO orders (customer_name, note, items_json, total_text, created_at, done)
           VALUES (?, ?, ?, ?, ?, 0)''',
        (customer_name, note, json.dumps(items, ensure_ascii=False), total_text, created_at)
    )
    order_id = cursor.lastrowid
    conn.commit()
    conn.close()

    return jsonify({
        'ok': True,
        'order_id': order_id,
        'total_text': total_text,
        'message': f'Шуточный заказ №{order_id} записан!',
    })


@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        if request.form.get('password', '') == ADMIN_PASSWORD:
            session['admin'] = True
            return redirect(url_for('admin'))
        flash('Неверный пароль', 'error')
    return render_template('admin_login.html')


@app.route('/admin/logout')
def admin_logout():
    session.clear()
    return redirect(url_for('index'))


@app.route('/admin')
@admin_required
def admin():
    conn = db()
    dishes = conn.execute('SELECT * FROM dishes ORDER BY sort_order, id').fetchall()
    raw_orders = conn.execute('SELECT * FROM orders ORDER BY id DESC LIMIT 100').fetchall()
    orders = []
    for order in raw_orders:
        item = dict(order)
        try:
            item['items'] = json.loads(item['items_json'])
        except (ValueError, TypeError):
            item['items'] = []
        orders.append(item)
    conn.close()
    return render_template('admin.html', dishes=dishes, orders=orders)


@app.route('/admin/dish/new', methods=['GET', 'POST'])
@admin_required
def dish_new():
    if request.method == 'POST':
        image_path = ''
        try:
            image_path = save_image(request.files.get('image'))
        except ValueError as exc:
            flash(str(exc), 'error')
            return render_template('dish_form.html', dish=None)

        conn = db()
        if request.form.get('featured'):
            conn.execute('UPDATE dishes SET featured = 0')
        conn.execute(
            '''INSERT INTO dishes
               (name, description, price, currency, emoji, image_path, available, featured, sort_order)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
            (
                request.form['name'].strip(),
                request.form.get('description', '').strip(),
                parse_price(request.form.get('price')),
                request.form.get('currency', '₽').strip()[:6] or '₽',
                request.form.get('emoji', '🍽️').strip() or '🍽️',
                image_path,
                1 if request.form.get('available') else 0,
                1 if request.form.get('featured') else 0,
                int(request.form.get('sort_order') or 0),
            )
        )
        conn.commit()
        conn.close()
        return redirect(url_for('admin'))
    return render_template('dish_form.html', dish=None)


@app.route('/admin/dish/<int:dish_id>', methods=['GET', 'POST'])
@admin_required
def dish_edit(dish_id):
    conn = db()
    dish = conn.execute('SELECT * FROM dishes WHERE id = ?', (dish_id,)).fetchone()
    if not dish:
        conn.close()
        return 'Не найдено', 404

    if request.method == 'POST':
        old_image = dish['image_path'] or ''
        image_path = old_image

        if request.form.get('remove_image'):
            remove_image(old_image)
            image_path = ''

        incoming = request.files.get('image')
        if incoming and incoming.filename:
            try:
                new_image = save_image(incoming)
            except ValueError as exc:
                conn.close()
                flash(str(exc), 'error')
                return redirect(url_for('dish_edit', dish_id=dish_id))
            if old_image and old_image != image_path:
                pass
            elif old_image:
                remove_image(old_image)
            image_path = new_image

        if request.form.get('featured'):
            conn.execute('UPDATE dishes SET featured = 0')
        conn.execute(
            '''UPDATE dishes
               SET name=?, description=?, price=?, currency=?, emoji=?, image_path=?, available=?, featured=?, sort_order=?
               WHERE id=?''',
            (
                request.form['name'].strip(),
                request.form.get('description', '').strip(),
                parse_price(request.form.get('price')),
                request.form.get('currency', '₽').strip()[:6] or '₽',
                request.form.get('emoji', '🍽️').strip() or '🍽️',
                image_path,
                1 if request.form.get('available') else 0,
                1 if request.form.get('featured') else 0,
                int(request.form.get('sort_order') or 0),
                dish_id,
            )
        )
        conn.commit()
        conn.close()
        return redirect(url_for('admin'))

    conn.close()
    return render_template('dish_form.html', dish=dish)


@app.post('/admin/dish/<int:dish_id>/delete')
@admin_required
def dish_delete(dish_id):
    conn = db()
    dish = conn.execute('SELECT image_path FROM dishes WHERE id = ?', (dish_id,)).fetchone()
    conn.execute('DELETE FROM dishes WHERE id = ?', (dish_id,))
    conn.commit()
    conn.close()
    if dish:
        remove_image(dish['image_path'])
    return redirect(url_for('admin'))


@app.post('/admin/order/<int:order_id>/toggle')
@admin_required
def order_toggle(order_id):
    conn = db()
    conn.execute('UPDATE orders SET done = CASE done WHEN 1 THEN 0 ELSE 1 END WHERE id = ?', (order_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('admin') + '#orders')


@app.post('/admin/order/<int:order_id>/delete')
@admin_required
def order_delete(order_id):
    conn = db()
    conn.execute('DELETE FROM orders WHERE id = ?', (order_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('admin') + '#orders')


init_db()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=6767, debug=True)
